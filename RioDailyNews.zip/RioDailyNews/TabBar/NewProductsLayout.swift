//
//  NewProductsLayout.swift
//  RionApp.com
//
//  Created by Rion on 26.2.23.
//

import Foundation
import UIKit


class ChooseProductLayout <C:DefaultCoordinator> : TabLayout {
    
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    var tabIdentifier: String{
        return "ChooseProduct"
    }
    
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "640px-Settings-icon-symbol-vector"), selectedImage: UIImage(named: "640px-Settings-icon-symbol-vector"))
    }
    
    func tabViewController() -> UIViewController? {
        self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        self.coordinator
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
}
