//
//  PersonalProfileLayout.swift
//  RionApp.com
//
//  Created by Rion on 23.1.23.
//

import Foundation
import UIKit
class PersonalProfileLayout<C:DefaultCoordinator> : TabLayout {
    
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    var tabIdentifier : String {
        return "PersonalProfile"
    }
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "homeSelected"), selectedImage: UIImage(named: "homeSelected"))
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func tabViewController() -> UIViewController? {
        return self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        return self.coordinator
    }
    
}

