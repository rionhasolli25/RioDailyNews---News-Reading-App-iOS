//
//  NewProfileLayout.swift
//  RionApp.com
//
//  Created by Rion on 25.1.23.
//

import Foundation
import UIKit

class NewProfileLayout<C:DefaultCoordinator> : TabLayout {
    
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    var tabIdentifier : String {
        return "NewProfile"
    }
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "group13"), selectedImage: UIImage(named: "group13"))
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left:  -10, bottom: -5, right:0)
    }
    func tabViewController() -> UIViewController? {
        return self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        return self.coordinator
    }
    
}

