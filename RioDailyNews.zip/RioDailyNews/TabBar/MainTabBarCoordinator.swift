//
//  MainTabBarCoordinator.swift
//  RionApp.com
//
//  Created by Rion on 10.1.23.
//

import Foundation
import UIKit

//class MainTabBarContainer: UITabBarController, Storyboarded {
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.navigationController?.navigationBar.isHidden = true
//    }
//}
class MainTabBarContainer: UITabBarController, Storyboarded {
    let layer = CAShapeLayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        layer.path = UIBezierPath(roundedRect: CGRect(x: 30, y: 5, width: self.tabBar.bounds.width - 70, height: self.tabBar.bounds.height + 8), cornerRadius: 23).cgPath
        layer.shadowColor = UIColor.darkGray.cgColor
        layer.shadowOffset = CGSize(width: 3.0, height: 3.0)
        layer.shadowRadius = 3
        layer.shadowOpacity = 0.5
        layer.borderWidth = 1.0
        layer.opacity = 1
        layer.masksToBounds = false
        layer.fillColor = UIColor.white.cgColor
        UITabBar.appearance().backgroundImage = UIImage()
        UITabBar.appearance().shadowImage = UIImage()
        UITabBar.appearance().clipsToBounds = true
        self.tabBar.layer.insertSublayer(layer, at: 0)
        if let items = self.tabBar.items {
            items.forEach { item in item.imageInsets = UIEdgeInsets(top: 40, left: 5, bottom: 0, right: 5) }
        }
        self.tabBar.itemPositioning = .centered
    }
    override func overrideTraitCollection(forChild childViewController: UIViewController) -> UITraitCollection? {
        let lieTrait = UITraitCollection(horizontalSizeClass: .regular)
        return lieTrait
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.tabBar.frame = CGRect( x: 0, y: UIScreen.main.bounds.height - 100, width: self.view.frame.width, height: 95)
    }
}

