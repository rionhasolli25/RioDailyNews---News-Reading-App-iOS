//
//  HomeLayout.swift
//  RionApp.com
//
//  Created by Rion on 10.1.23.
//

import Foundation
import UIKit
/**
 Class for Notifications TabLayout
 - Parameters:
 - Coorindator: DefaultCoordinator that handles routing for the Notifications Tab Bar
 */
class HomeLayout<C:DefaultCoordinator> : TabLayout {
    
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    var tabIdentifier : String {
        return "Home"
    }
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "houseNotClicked"), selectedImage: UIImage(named: "homeSelected")) 
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 0, bottom: -5, right: 0)
    }
    func tabViewController() -> UIViewController? {
        return self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        return self.coordinator
    }
    
}
