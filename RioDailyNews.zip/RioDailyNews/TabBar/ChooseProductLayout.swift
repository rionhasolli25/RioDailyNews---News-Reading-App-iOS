//
//  ChooseProductLayout.swift
//  RioDailyNews
//
//  Created by Rion on 24.9.25.
//
import UIKit

class ChooseyProductLayout <C:DefaultCoordinator> : TabLayout {
    
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    var tabIdentifier: String{
        return "NewProfile"
    }
    
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "640px-Settings-icon-symbol-vector"), selectedImage: UIImage(named: "640px-Settings-icon-symbol-vector"))
    }
    
    func tabViewController() -> UIViewController? {
        self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        self.coordinator
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
}
