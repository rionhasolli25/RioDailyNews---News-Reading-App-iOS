//
//  BitcoinNewsLayout.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//
import UIKit

class BitcoinNewsLayout<C:DefaultCoordinator> : TabLayout {
    
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    var tabIdentifier : String {
        return "BitcoinNews"
    }
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "homeSelected"), selectedImage: UIImage(named: "homeSelected"))
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets(top:5, left: 0, bottom: -5, right: 30)
    }
    func tabViewController() -> UIViewController? {
        return self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        return self.coordinator
    }
    
}
