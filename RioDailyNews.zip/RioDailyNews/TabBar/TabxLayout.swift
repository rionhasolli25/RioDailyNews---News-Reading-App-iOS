//
//  TabxLayout.swift
//  RionApp.com
//
//  Created by Rion on 10.1.23.
//

import Foundation
import UIKit
protocol TabLayout {
    var tabIdentifier : String {get}
    func tabBarItem() -> UITabBarItem
    func tabViewController() -> UIViewController?
    func tabViewCoordinator() -> Coordinator
    func imageInsets() -> UIEdgeInsets
}
