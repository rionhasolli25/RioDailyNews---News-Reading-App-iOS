//
//  NewsListLayout.swift
//  RioDailyNews
//
//  Created by Rion on 19.9.25.
//

import Foundation
import UIKit

class NewsListLayout<C: DefaultCoordinator> : TabLayout{
    let coordinator : C
    init(coordinator:C) {
        self.coordinator = coordinator
    }
    
    var tabIdentifier: String{
        return "NewsList"
    }
    func tabBarItem() -> UITabBarItem {
        return UITabBarItem(title: nil, image: UIImage(named: "Eyes"), selectedImage: UIImage(named: "Eyes"))
    }
    
    func imageInsets() -> UIEdgeInsets {
        return UIEdgeInsets (top: 5, left: -10, bottom: -5, right: 0)

    }
    func tabViewController() -> UIViewController? {
        return self.coordinator.viewController
    }
    
    func tabViewCoordinator() -> Coordinator {
        return self.coordinator
    }
}
