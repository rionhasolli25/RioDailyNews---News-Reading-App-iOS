//
//  MainLayoutProtocol.swift
//  RionApp.com
//
//  Created by Rion on 10.1.23.
//

import Foundation
protocol MainAppLayoutProtocol {
    var parentCoordinator : CoordinatorDelegate? {get set}
    var orderedTabs :  [TabLayout] {get}
}

// Main Class that returns the supported  bars for the Home Screen
class MainAppLayout : MainAppLayoutProtocol {
    var ID : Int?
    var parentCoordinator: CoordinatorDelegate?
    var orderedTabs : [TabLayout] {
        get {
            return [
                HomeLayout(coordinator: HomeCoordinator(viewModel: HomeViewModel())),
                NewsListLayout(coordinator: NewsListCoordinator(viewModel: NewsListViewModel())),
                NewProfileLayout(coordinator: NewProfileCoordinator(viewModel: TechNewsViewModel()))
              
//
            ]
        }
    }
}
