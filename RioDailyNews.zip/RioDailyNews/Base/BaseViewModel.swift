//
//  BaseViewModel.swift
//  RionApp.com
//
//  Created by Rion on 24.9.22.
//

import Foundation

protocol BaseViewModel : AnyObject{
    
}
