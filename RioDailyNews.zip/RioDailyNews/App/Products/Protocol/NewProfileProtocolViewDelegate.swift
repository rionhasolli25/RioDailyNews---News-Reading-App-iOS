//
//  NewProfileProtocolViewDelegate.swift
//  RionApp.com
//
//  Created by Rion on 25.1.23.
//

import Foundation


protocol NewProfileProtocolViewDelegate : AnyObject{
    func openUrl(url:String)
    
}
