//
//  USNewsViewDelegate.swift
//  RioDailyNews
//
//  Created by Rion on 6.10.25.
//


protocol USNewsViewDelegate : AnyObject{
    func showURL(url:String)
}
