//
//  NewsListCoordinator.swift
//  RioDailyNews
//
//  Created by Rion on 19.9.25.
//

class NewsListCoordinator: DefaultCoordinator{
  
    
    var viewController : NewsListViewController?
    var viewModel : NewsListViewModelProtocol?
    var coordinateDelegate : NewsListViewProtocolDelegate?
    
    
    init(viewModel: NewsListViewModelProtocol = NewsListViewModel()) {
        self.viewModel = viewModel
        self.viewModel?.coordinateDelegate = self
    }
    func start() {
        self.viewController = NewsListViewController.instantiate(.newsList)
        self.viewController?.viewModel = self.viewModel
    }
}
extension NewsListCoordinator : NewsListViewProtocolDelegate{
    func showScreen() {
        
    }
    func openWebPage(url: String) {
    }
}
