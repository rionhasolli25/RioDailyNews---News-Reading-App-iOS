//
//  NewsListTableViewCell.swift
//  RioDailyNews
//
//  Created by Rion on 18.9.25.
//

import UIKit

class NewsListTableViewCell: UITableViewCell {

    @IBOutlet weak var newsDesc: UILabel!
    @IBOutlet weak var newsTitle: UILabel!
    @IBOutlet weak var newsImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var sportArticle : SportArticle!{
        didSet{
            setValues()
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setDate(date: String){
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T"
            guard let convertedDate = formatter.date(from: date) else {return}
            self.newsDesc.text = "\(convertedDate.toString(format : "DD/MM/YY"))"
    }
    func setValues(){
        if let image  = sportArticle.urlToImage, image != ""{
            self.newsImageView.setImage(with: image)
        }
    
        else{
            self.newsImageView.image = UIImage(named: "No_Image_Available")
        }
        self.newsTitle.text = sportArticle.title ?? ""
        self.newsDesc.text = sportArticle.publishedAt ?? ""
        self.newsImageView?.cornerRadius = 10
        
        if let dateformat = sportArticle.publishedAt{
            setDate(date: dateformat)
        }
    }
}
