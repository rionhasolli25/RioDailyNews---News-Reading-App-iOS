//
//  NewsListViewController.swift
//  RioDailyNews
//
//  Created by Rion on 18.9.25.
//

import UIKit
import WebKit
import SafariServices

class NewsListViewController: UIViewController,Storyboarded,SFSafariViewControllerDelegate,WKUIDelegate{
   

    @IBOutlet weak var searchResults: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var tableView: UITableView!
    var viewModel : NewsListViewModelProtocol?
    var webkit : WKWebView?
    
    var sportArticle : [SportArticle]?
    var filteredResults : [SportArticle]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.alwaysBounceVertical = true
        setTableView()
        setupAPI()
        addPullToRefresh()
        setupTextFields()
        self.viewModel?.viewProtocolDelegate = self
    }
    func setTableView(){
        self.tableView.register(NewsListTableViewCell.self)
        self.tableView.delegate = self.viewModel?.dataSource
        self.tableView.dataSource = self.viewModel?.dataSource
        self.tableView.separatorColor = UIColor.clear
    }
    func setupTextFields(){
        searchResults.addTarget(self, action: #selector(searchTextChanged(_:)), for: .editingChanged)
    }
    @objc func searchTextChanged(_ sender: UITextField){
        let search = sender.text ?? ""
        if search.count == 0{
            self.viewModel?.getSportList(list: filteredResults)
            self.tableView.reloadData()
        }
        else{
            filterText(search)
        }
    }
    func filterText(_ searchText :String){
        self.filteredResults?.removeAll()
        self.filteredResults = sportArticle?.filter({ filter in
            return "\(filter.title?.lowercased() ?? "")".contains(searchText.lowercased())
        })
        self.viewModel?.getSportList(list: filteredResults)
        tableView.reloadData()
    }
    func addPullToRefresh() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshContent), for: .valueChanged)
        tableView.refreshControl = refreshControl
    }


    @objc private func refreshContent() {
        setupAPI()
        tableView.refreshControl?.endRefreshing()
    }

    func setupAPI(){
        self.viewModel?.getSportNews(completion: { response in
            HIDE_CUSTOM_LOADER()
            if let results = response?.articles{
                self.sportArticle = results
                self.viewModel?.getSportList(list: response?.articles)
            }
            dispatch {
                self.tableView.reloadData()
            }
        })
    }

}
extension NewsListViewController : NewsListViewModelProtocolViewDelegate{
    func openWebPage(url: String) {
        guard let url = URL(string: url) else {
        return
        }
        let safariVC = SFSafariViewController(url: url)
        safariVC.delegate = self
        present(safariVC, animated: true)
        }
    func showScreen() {
        
    }
    
    }
