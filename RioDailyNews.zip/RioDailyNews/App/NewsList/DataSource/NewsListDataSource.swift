//
//  NewsListDataSource.swift
//  RioDailyNews
//
//  Created by Rion on 18.9.25.
//

import UIKit
import Foundation


protocol NewsSportsDataSourceProtocol : AnyObject{
    func openWebPage(url:String)
}

class NewsSportsDataSource: NSObject,UITableViewDelegate,UITableViewDataSource{
    
    var sportArticle: [SportArticle]?
    var delegate : NewsSportsDataSourceProtocol?
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sportArticle?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeue(NewsListTableViewCell.self, for: indexPath)
        if let sportArticle = sportArticle?[indexPath.row]{
            cell.sportArticle = sportArticle
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let url = sportArticle?[indexPath.row].url else { return }
        self.delegate?.openWebPage(url: url)
        print(url)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
}
