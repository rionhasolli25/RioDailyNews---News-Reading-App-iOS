//
//  NewsListViewModel.swift
//  RioDailyNews
//
//  Created by Rion on 18.9.25.
//

import Foundation

protocol NewsListViewModelProtocolViewDelegate : AnyObject{
    func openWebPage(url: String)
}
class NewsListViewModel: NewsListViewModelProtocol{
  
    
    var coordinateDelegate: NewsListViewProtocolDelegate?
    var viewProtocolDelegate: NewsListViewModelProtocolViewDelegate?
    var dataSource: NewsSportsDataSource?
    
    init(){
        dataSource = NewsSportsDataSource()
        dataSource?.delegate = self
    }
    
    func getSportList(list: [SportArticle]?) {
        self.dataSource?.sportArticle = list
    }
    
    func getSportNews(completion: @escaping ((Sportnews?) -> Void)) {
        let auth = AuthenticationClient.getSportNews()
        auth.execute(onSuccess: { response in
            completion(response)
        }, onFailure: { error in
            completion(nil)
        })
    }
    func showScreen() {
        
    }
    
    
}

extension NewsListViewModel : NewsSportsDataSourceProtocol{
    func openWebPage(url: String) {
        self.viewProtocolDelegate?.openWebPage(url: url)
        print("print Viewmodel url:\(String(describing: url))")
    }
}
