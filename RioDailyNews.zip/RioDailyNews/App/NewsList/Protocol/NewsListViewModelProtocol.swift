//
//  NewsListViewModelProtocol.swift
//  RioDailyNews
//
//  Created by Rion on 18.9.25.
//

protocol NewsListViewModelProtocol : BaseViewModel{
    var viewProtocolDelegate : NewsListViewModelProtocolViewDelegate? {get set}
    var coordinateDelegate: NewsListViewProtocolDelegate? {get set}
    var dataSource : NewsSportsDataSource? {get set}
    func getSportList(list:[SportArticle]?)
    func getSportNews(completion : @escaping((Sportnews?) -> Void))
    func openWebPage(url:String)
    func showScreen()
}
