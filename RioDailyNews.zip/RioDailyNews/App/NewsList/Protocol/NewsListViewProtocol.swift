//
//  NewsListViewProtocol.swift
//  RioDailyNews
//
//  Created by Rion on 18.9.25.
//

import Foundation

protocol NewsListViewProtocolDelegate: AnyObject{
    func showScreen()
    func openWebPage(url:String)
}
