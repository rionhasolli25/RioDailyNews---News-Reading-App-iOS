//
//  ChooseProductViewController.swift
//  RionApp.com
//
//  Created by Rion on 13.2.23.
//

import UIKit

class ChooseProductViewController: UIViewController,Storyboarded{
    

    @IBOutlet weak var toggleBtn: UISwitch!
    @IBOutlet weak var tableView: UITableView!
    var viewModel : ChooseProductViewModelProtocol?
    var coordiantor : ChooseProductCoordinator?
    var insurance : [Product]?
    var filteredResults : [Product]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        toggleBtn.isOn = false
        setupTable()
    }
    @IBAction func toggleBtn(_ sender: Any) {
        if toggleBtn.isOn == false{
            let window = UIApplication.shared.windows[0]
            window.overrideUserInterfaceStyle = .light
        }
        else{
            let window = UIApplication.shared.windows[0]
            window.overrideUserInterfaceStyle = .dark
        }
    }
    func setupTable(){
        self.tableView.register(OthersListTableViewCell.self)
        self.tableView.delegate = self.viewModel?.dataSource
        self.tableView.dataSource = self.viewModel?.dataSource
    }
}
