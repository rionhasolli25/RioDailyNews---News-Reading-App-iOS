//
//  ChooseNewProductViewDelegate.swift
//  RionApp.com
//
//  Created by Rion on 23.2.23.
//

import Foundation


protocol ChooseNewProductViewDelegate : AnyObject{
    func showProducts(id:Int)
}
