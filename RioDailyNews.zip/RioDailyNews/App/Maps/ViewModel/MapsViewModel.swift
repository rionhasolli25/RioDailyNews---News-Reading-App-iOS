//
//  MapsViewModel.swift
//  RioDailyNews
//
//  Created by Rion on 6.10.25.
//

class MapsViewModel : MapsViewModelProtocol{
    var coordinateDelegate: MapsViewProtocolDelegate?
    
    init(){
        
    }
    
    func showmap() {
        
    }
    
    
}
