//
//  MapsViewProtocolDelegate.swift
//  RioDailyNews
//
//  Created by Rion on 6.10.25.
//

protocol MapsViewProtocolDelegate : AnyObject{
    func makemaps()
}
