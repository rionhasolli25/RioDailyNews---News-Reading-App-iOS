//
//  BitcoinNewsDataSource.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

import UIKit
import Foundation

protocol BitcoinNewsDataSourceProtocol : AnyObject{
    func openWebpage(url: String)
}

class BitcoinNewsDataSource : NSObject,UITableViewDelegate,UITableViewDataSource{
    
    var delegate : BitcoinNewsDataSourceProtocol?
    var bitcoinArray : [BitcoinArticle]?
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bitcoinArray?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeue(BitcoinNewsTableViewCell.self, for: indexPath)
        if let appleNews = bitcoinArray?[indexPath.row]{
            cell.bitcoinArray = appleNews
        }
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let selectedArray = bitcoinArray?[indexPath.row].url else {return}
        self.delegate?.openWebpage(url: selectedArray)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }
    
}
