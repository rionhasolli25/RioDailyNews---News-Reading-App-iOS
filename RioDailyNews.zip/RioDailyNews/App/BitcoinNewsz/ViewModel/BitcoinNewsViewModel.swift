//
//  BitcoinNewsViewModel.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

protocol BitcoinNewsViewModelViewDelegate : AnyObject{
    func openWebPage(url:String)
}

class BitcoinNewsViewModel : BitcoinNewsViewModelProtocol{
   
    var delegate: BitcoinNewsViewDelegate?
    var bitcoinDataSource : BitcoinNewsDataSource?
    var viewDelegate : BitcoinNewsViewModelViewDelegate?
    
    init(){
        bitcoinDataSource = BitcoinNewsDataSource()
        self.bitcoinDataSource?.delegate = self
    }
    
    func getBitcoinNews(completion: @escaping ((Bitcoin?)) -> Void) {
        let auth = AuthenticationClient.getBitcoinNews()
        auth.execute(onSuccess: { response in
            completion(response)
        }, onFailure: { error in
            completion(nil)
        })
    }
    
    func getBitcoinNewslist(list: [BitcoinArticle]?) {
        self.bitcoinDataSource?.bitcoinArray = list
    }
}

extension BitcoinNewsViewModel : BitcoinNewsDataSourceProtocol{
    func openWebpage(url: String) {
        self.viewDelegate?.openWebPage(url: url)
    }
}
