//
//  BitcoinNewsTableViewCell.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

import UIKit

class BitcoinNewsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var bitcoinNwTitle: UILabel!
    @IBOutlet weak var bitcoinNwImage: UIImageView!
    var bitcoinArray : BitcoinArticle!{
        didSet{
            setValues()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setValues(){
        self.bitcoinNwImage.cornerRadius = 20
        self.bitcoinNwTitle.text = bitcoinArray.title ?? ""
        if let img = bitcoinArray.urlToImage,img != ""{
            bitcoinNwImage.setImage(with: img)
        }
    }
}
