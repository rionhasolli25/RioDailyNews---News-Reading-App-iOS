//
//  BitcoinNewsViewController.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

import UIKit

class BitcoinNewsViewController: UIViewController,Storyboarded {

    @IBOutlet weak var bitcoinTableView: UITableView!
    
    var viewModel : BitcoinNewsViewModelProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        setupAPI()
    }
    func setupTableView(){
        bitcoinTableView.register(BitcoinNewsTableViewCell.self)
        bitcoinTableView.dataSource = self.viewModel?.bitcoinDataSource
        bitcoinTableView.delegate = self.viewModel?.bitcoinDataSource
        bitcoinTableView.separatorColor = UIColor.clear
    }

    func setupAPI(){
        self.viewModel?.getBitcoinNews(completion: { response in
            HIDE_CUSTOM_LOADER()
            print(response ?? "")
            self.viewModel?.getBitcoinNewslist(list: response?.articles)
            self.bitcoinTableView.reloadData()
        })
    }
}
