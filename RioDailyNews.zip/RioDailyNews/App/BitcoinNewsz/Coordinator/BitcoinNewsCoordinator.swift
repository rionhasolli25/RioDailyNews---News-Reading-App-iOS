//
//  Untitled.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

class BitcoinNewsCoordinator : DefaultCoordinator{
   
    var viewController : BitcoinNewsViewController?
    var viewModel : BitcoinNewsViewModelProtocol?
    var coordinateDelegate : BitcoinNewsViewDelegate?
       
    init(viewModel: BitcoinNewsViewModelProtocol = BitcoinNewsViewModel()) {
            self.viewModel = viewModel
        self.viewModel?.delegate = self
        }
        func start() {
            self.viewController = BitcoinNewsViewController.instantiate(.bitcoinNews)
            self.viewController?.viewModel = self.viewModel
    
    }
}

extension BitcoinNewsCoordinator : BitcoinNewsViewDelegate{
    
}
