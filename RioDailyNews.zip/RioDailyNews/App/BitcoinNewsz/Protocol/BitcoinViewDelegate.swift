//
//  BitcoinViewDelegate.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

import Foundation

protocol BitcoinNewsViewDelegate : AnyObject{
    
}
