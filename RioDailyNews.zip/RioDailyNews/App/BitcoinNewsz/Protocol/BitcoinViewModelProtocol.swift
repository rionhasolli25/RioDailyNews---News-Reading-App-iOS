//
//  BitcoinViewModelProtocol.swift
//  RioDailyNews
//
//  Created by Rion on 23.9.25.
//

protocol BitcoinNewsViewModelProtocol : BaseViewModel{
    var delegate : BitcoinNewsViewDelegate? {get set}
    var bitcoinDataSource : BitcoinNewsDataSource? {get set}
    func getBitcoinNews(completion : @escaping((Bitcoin?))-> Void)
    func getBitcoinNewslist(list : [BitcoinArticle]?)
}
