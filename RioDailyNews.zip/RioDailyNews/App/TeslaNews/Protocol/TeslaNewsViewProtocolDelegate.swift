//
//  TeslaNewsViewProtocolDelegate.swift
//  RioDailyNews
//
//  Created by Rion on 21.9.25.
//

protocol TeslaNewsViewProtocolDelegate: AnyObject{
    func protocoldelegate()
}
