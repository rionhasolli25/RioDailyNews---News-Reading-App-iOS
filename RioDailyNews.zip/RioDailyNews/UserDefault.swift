//
//  UserDefault.swift
//  RioDailyNews
//
//  Created by Rion on 8.10.25.
//
import Foundation

import Foundation

final class FavoritesManager {
    static let shared = FavoritesManager()
    private let favoritesKey = "favorite_articles"

    private init() {}

    // MARK: - Save Article
    func save(_ article: LatestArticle) {
        var current = getAll()
        // Avoid duplicates
        if !current.contains(article) {
            current.append(article)
            saveToUserDefaults(current)
        }
    }

    // MARK: - Remove Article
    func remove(_ article: LatestArticle) {
        var current = getAll()
        current.removeAll { $0.id == article.id }
        saveToUserDefaults(current)
    }

    // MARK: - Get All
    func getAll() -> [LatestArticle] {
        guard let data = UserDefaults.standard.data(forKey: favoritesKey) else {
            return []
        }
        do {
            return try JSONDecoder().decode([LatestArticle].self, from: data)
        } catch {
            print("❌ Failed to decode favorites: \(error)")
            return []
        }
    }

    // MARK: - Check if Favorite
    func isFavorite(_ article: LatestArticle) -> Bool {
        return getAll().contains(where: { $0.id == article.id })
    }

    // MARK: - Save to UserDefaults
    private func saveToUserDefaults(_ articles: [LatestArticle]) {
        do {
            let data = try JSONEncoder().encode(articles)
            UserDefaults.standard.set(data, forKey: favoritesKey)
        } catch {
            print("❌ Failed to encode favorites: \(error)")
        }
    }
}


